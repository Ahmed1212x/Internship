﻿using AdcHmiFinal.BLL.Data;

using AutoMapper;

namespace AdcHmiFinal.Profiles
{
    internal class ModelProfile : Profile
    {

        public ModelProfile()
        {
            CreateMap<DataViewModel, DataModel>();
            CreateMap<DataModel, DataViewModel>();

        }
    }
}
