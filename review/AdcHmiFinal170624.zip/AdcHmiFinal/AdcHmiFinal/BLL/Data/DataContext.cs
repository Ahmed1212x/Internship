﻿

namespace AdcHmiFinal.BLL.Data
{
    class DataContext
    {
        public string StrMessage { get; internal set; } = string.Empty;

        public bool CommandIsOn { get; set; }

        public IList<double> AdcOne { get; set; } = new List<double>();
        public IList<double> AdcTwo { get; set; } = new List<double>();
        public IList<double> AdcThree { get; set; } = new List<double>();



        public int AdcOneCounter { get; set; }
        public int AdcTwoCounter { get; set; }
        public int AdcThreeCounter { get; set; }


    }
}
