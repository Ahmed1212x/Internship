﻿using AdcHmiFinal.BLL.Serial;

namespace AdcHmiFinal.BLL.Data
{
    class DataModel
    {

        public string Message { get; internal set; } = String.Empty;

        public IList<double> AdcOne { get; set; } = new List<double>();
        public IList<double> AdcTwo { get; set; } = new List<double>();
        public IList<double> AdcThree { get; set; } = new List<double>();



        public int AdcOneCounter { get; set; }
        public int AdcTwoCounter { get; set; }
        public int AdcThreeCounter { get; set; }

    }
}
