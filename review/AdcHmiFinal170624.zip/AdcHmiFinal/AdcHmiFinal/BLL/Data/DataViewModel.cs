﻿using AdcHmiFinal.BLL.Serial;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace AdcHmiFinal.BLL.Data
{
    class DataViewModel : INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler? PropertyChanged;
        public DataViewModel()
        {

        }

        public bool IsOnCommand { get; internal set; }

        private IList<double> adcOne = new List<double>();
        private IList<double> adcTwo = new List<double>();
        private IList<double> adcThree = new List<double>();


       
        public IList<double> AdcOne
        {
            get { return adcOne; }
            set
            {
                adcOne = value;
                OnPropertyChanged();
            }
        }

        public IList<double> AdcTwo
        {
            get { return adcTwo; }
            set { adcTwo = value; OnPropertyChanged(); }
        }

        public IList<double> AdcThree
        {
            get { return adcThree; }
            set { adcThree = value; OnPropertyChanged(); }
        }

       

        private int adcOneCounter, adcTwoCounter, adcThreeCounter;


        public int AdcOneCounter { get { return adcOneCounter; } set { adcOneCounter = value; OnPropertyChanged(); } }

        public int AdcTwoCounter { get { return adcTwoCounter; } set { adcTwoCounter = value; OnPropertyChanged(); } }
        public int AdcThreeCounter { get { return adcThreeCounter; } set { adcThreeCounter = value; OnPropertyChanged(); } }






        protected void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }





    }


}
