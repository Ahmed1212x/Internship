﻿using AdcHmiFinal.Profiles;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdcHmiFinal.BLL.Handler
{
    internal class AutomapperHandler
    {

        private static Mapper? mapper;
        private AutomapperHandler()
        {

        }
        public static Mapper GetMapper()
        {

            if (mapper == null)
            {
                var configuration = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<ModelProfile>();
            });
                mapper = new(configuration);
            }
            return mapper;

        }


    }
}
