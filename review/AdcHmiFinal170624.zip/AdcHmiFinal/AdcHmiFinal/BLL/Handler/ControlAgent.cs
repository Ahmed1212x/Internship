﻿using AdcHmiFinal.BLL.Data;
using AdcHmiFinal.BLL.Serial;
using AutoMapper;
using System.Windows.Threading;



namespace AdcHmiFinal.BLL.Handler
{
    class ControlAgent
    {
        private const int UiRefreshTime = 100;

        private readonly DispatcherTimer? _UiRefreshTimer;
        private readonly DataModel? _Model;
        private readonly DataContext? _dataContext = new();
        private SerialClient? _serialHandler;

        private readonly Mapper? _mapper;

        private bool _UISelected = false;

        public bool UISelected
        {
            //private get
            // {
            //     return _UISelected;
            // }
            set
            {
                _UISelected = value;
            }
        }

        public DataViewModel? DataViewModel
        {
            get;
            set;
        }

        public ControlAgent()
        {
            try
            {
                _Model = new();
                DataViewModel = new();

                _UiRefreshTimer = new();
                _UiRefreshTimer.Tick += UIRefreshTimer_Tick;
                _UiRefreshTimer.Interval = new(0, 0, 0, 0, UiRefreshTime);
                _UiRefreshTimer.Start();


                _mapper = AutomapperHandler.GetMapper();
                IntializeSerialHandler();


            }
            catch (Exception)
            {
            }
        }

        private void UIRefreshTimer_Tick(object? sender, EventArgs e)
        {
            if (_UISelected)
            {
                PopulateScreenData();
            }
        }
        Random r = new();
        private void PopulateScreenData()
        {
            if (_Model == null)
                return;
            try
            {
                if (_dataContext == null)
                    return;


                _Model.Message = _dataContext.StrMessage;

                _Model.AdcOne = _dataContext.AdcOne;
                _Model.AdcTwo = _dataContext.AdcTwo;
                _Model.AdcThree = _dataContext.AdcThree;

                _Model.AdcOneCounter = _dataContext.AdcOneCounter;
                _Model.AdcTwoCounter = _dataContext.AdcTwoCounter;
                _Model.AdcThreeCounter = _dataContext.AdcThreeCounter;


                if (_mapper == null)
                    return;

                _mapper.Map(_Model, DataViewModel);


            }
            catch (Exception)
            {

            }
        }

        public void HandleCommands(object? sender, EventArgs e)
        {
            if (DataViewModel == null || _dataContext == null)
                return;
            _dataContext.CommandIsOn = DataViewModel.IsOnCommand;


        }

        private void IntializeSerialHandler()
        {
            _serialHandler = new();
            if (_dataContext == null)
                return;
            _serialHandler.Start(_dataContext);

        }

        #region IDisposable Members

        private bool _disposed;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {

                    _serialHandler?.Dispose();


                }
                _disposed = true;
            }
        }
        #endregion

    }
}