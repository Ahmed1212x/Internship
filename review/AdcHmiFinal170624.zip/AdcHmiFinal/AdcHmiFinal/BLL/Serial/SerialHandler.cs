﻿
using System.IO.Ports;

namespace AdcHmiFinal.BLL.Serial
{
    class SerialHandler
    {



        public event EventHandler<MsgEventArgs>? ReceivePlcMsgEvent;

        private SerialPort? _SerialPort;
        private const string PortName = "Com1";
        private const int BaudRate = 105200;

        public SerialHandler()
        {

            Initialize();

        }
        private bool Initialize()
        {
            try
            {
                _SerialPort = new SerialPort(PortName, BaudRate, Parity.Odd)
                {
                    ReadTimeout = 500,
                    WriteTimeout = 500
                };//115200                

                if (!_SerialPort.IsOpen)
                    _SerialPort.Open();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool SendPacket(byte[] packet, int packetSize)
        {
            if (_SerialPort == null || packet == null || packet.Length < packetSize || packetSize <= 0)
                return false;

            try
            {
                _SerialPort.Write(packet, 0, packetSize);
                return true;
            }
            catch (Exception ex)
            {
                OnReceivePlcMsgEvent(new MsgEventArgs(ex.Message));
                return false;
            }
        }
        public bool ReceivePacket(byte[] packet, int packetSize)  //ASSERT packet is not null
        {
            var superheader = new byte[2];
            int count = 0;
            if (packet == null || packet.Length <= 0 || packetSize <= 0||_SerialPort == null)
            {

                OnReceivePlcMsgEvent(new MsgEventArgs("Packet size is not valid"));
                return false;
            }
           
            try
            {
                Array.Clear(superheader, 0, superheader.Length);
                Array.Clear(packet, 0, packet.Length);
                do
                {
                    superheader[1] = superheader[0];
                    try
                    {
                        _SerialPort.Read(superheader, 0, 1);

                        count++;
                    }
                    catch (TimeoutException)
                    {
                        OnReceivePlcMsgEvent(new MsgEventArgs("Unable to receive data packet from CU"));
                        return false;
                    }
                }
                while ((superheader[1] != 0xC5 || superheader[0] != 0xC5) && (count >= 0 && count < 5));

                if (count >= 5)
                {
                    OnReceivePlcMsgEvent(new MsgEventArgs("Unable to receive packet header from CU"));
                    return false;
                }
                packet[0] = superheader[1];
                packet[1] = superheader[0];
                int byteind = 2;
                int bytesremain = packet.Length - 2;
                do
                {
                    try
                    {
                        if (byteind > 0 && bytesremain > 0)
                        {
                            int bytesRead =
                                                _SerialPort.Read(packet, byteind, bytesremain);
                            bytesremain -= bytesRead;
                            byteind += bytesRead;
                        }
                    }
                    catch (TimeoutException)
                    {
                        OnReceivePlcMsgEvent(new MsgEventArgs("Incomplete packet received from CU"));
                        return false;
                    }
                }//Exit For Loop
                while (bytesremain > 0);
            }
            catch (Exception ex)
            {
                OnReceivePlcMsgEvent(new MsgEventArgs(ex.Message));
                return false;
            }
            return true;
        }
        protected virtual void OnReceivePlcMsgEvent(MsgEventArgs cuMsg)
        {
            ReceivePlcMsgEvent?.Invoke(this, cuMsg);
        }

        public void Dispose()
        {
            try
            {
                _SerialPort?.Dispose();
               
            }
            catch (Exception)
            {

                throw;
            }
        }
    }

    public class MsgEventArgs(string s) : EventArgs
    {
        private string _message = s;

        public string Message
        {
            get { return _message; }
            set { _message = value; }
        }
    }


}



