﻿using AdcHmiFinal.BLL.Data;
using AdcHmiFinal.Properties;
using System;
using System.Configuration;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;

namespace AdcHmiFinal.BLL.Serial
{

    class SerialClient
    {
        //private bool _commandSent;
        private SerialHandler? _serialHandler;
        private static BinaryWriter _logWriter;

        private Thread? _DataThread;

        private readonly byte[] _Data = new byte[16];
        private readonly byte[] _CommandData = new byte[16];

        private bool _stopData;

        private DataContext _DataContext = new();



        internal object CULock
        {
            get;
        } = new();


        private bool _retval;

        public SerialClient()
        {

        }

        public void Start(DataContext dataContext)
        {
            try
            {
                _serialHandler = new SerialHandler();

                _DataContext = dataContext;
                
                string fileName = GenerateLogFileName();

                if (fileName != null)
                    _logWriter = new BinaryWriter(new FileStream(fileName, FileMode.CreateNew));
                _serialHandler.ReceivePlcMsgEvent += HandlePLCMsgEvent;
                _DataThread = new Thread(CommunicateWithSerialPort);
                _DataThread.Start();


            }
            catch (Exception)
            {

            }

        }

        private static string GenerateLogFileName()
        {
            DateTime currentDateTime = DateTime.Now.Date;
            DateTime storedDateTime = Settings.Default.StoredDate.Date;

            if (storedDateTime != currentDateTime)
            {
                Settings.Default.StoredDate = currentDateTime;
                Settings.Default.StoredCounter = 1;
                Settings.Default.Save();
            }

            string fileName = String.Format("{0}{1}.bin", Settings.Default.StoredDate.ToString("ddMMyyyy"), Settings.Default.StoredCounter.ToString("D5"));
            Settings.Default.StoredCounter++;
            Settings.Default.Save();
            return fileName;

        }


        private void CommunicateWithSerialPort()
        {
            if (_serialHandler == null)
                return;
            _DataContext.StrMessage = "Waiting for Connection Establishment";

            do
            {

                try
                {
                    _retval = _serialHandler.ReceivePacket(_Data, _Data.Length);
                    Log(_Data);
                    if (_retval)
                    {
                        if (ValidateDataPacket())
                        {


                            FillSerialContext();
                        }
                    }
                    else
                    {
                        Array.Clear(_Data, 0, _Data.Length);
                        FillSerialContext();
                    }

                    FillCommandPacket();
                    _retval = _serialHandler.SendPacket(_CommandData, _CommandData.Length);
                    Log(_CommandData);
                    if (_retval)
                        _DataContext.CommandIsOn = false;
                    Thread.Sleep(500);

                }
                catch (TimeoutException)
                {
                    _DataContext.StrMessage = "Waiting for Connection Establishment";
                }
                catch (Exception)
                {
                    _DataContext.StrMessage = "Waiting for Connection Establishment";
                }


            } while (!_stopData);
        }

        private void FillCommandPacket()
        {

            _CommandData[0] = _CommandData[1] = 0xFE;

            _CommandData[1] = (byte)(_DataContext.CommandIsOn ? 0xAA : 0x55);

            byte[] checksum = CalculateCheckSum(_CommandData);
            _CommandData[14] = checksum[0];
            _CommandData[15] = checksum[1];


        }


        private void FillSerialContext()
        {
            if (_DataContext == null)
                return;

            try
            {

                double adcOneData = BitConverter.ToUInt16(_Data, 7) * Scalefactors.Adc1;
                double adcTwoData = BitConverter.ToUInt16(_Data, 9) * Scalefactors.Adc2;
                double adcThreeData = BitConverter.ToUInt16(_Data, 11) * Scalefactors.Adc3;

                if (_DataContext.AdcOneCounter < Scalefactors.ArraySize)
                {
                    _DataContext.AdcOne.Add(adcOneData);
                    _DataContext.AdcOneCounter++;

                }
                else
                {
                    _DataContext.AdcOneCounter = 0;
                }


                if (_DataContext.AdcTwoCounter < Scalefactors.ArraySize)
                {
                    _DataContext.AdcTwo.Add(adcTwoData);
                    _DataContext.AdcTwoCounter++;
                }
                else
                {
                    _DataContext.AdcTwoCounter = 0;
                }

                if (_DataContext.AdcThreeCounter < Scalefactors.ArraySize)
                {
                    _DataContext.AdcThree.Add(adcThreeData);
                    _DataContext.AdcThreeCounter++;
                }
                else
                {
                    _DataContext.AdcThreeCounter = 0;
                }


            }
            catch (Exception)
            {
                _DataContext.StrMessage = "Error in Data recieving";
            }
        }



        private bool ValidateDataPacket()
        {
            bool retVal = true;
            try
            {


                if (_Data[0] != 0xFE || _Data[1] != 0xFE)
                {
                    retVal = false;

                }
                else if (!ValidateCheckSum(_Data))
                {
                    retVal = false;

                }

            }
            catch (Exception)
            {

                return false;
            }
            return retVal;
        }

        public void HandlePLCMsgEvent(object? sender, MsgEventArgs e)
        {
            try
            {
                _DataContext.StrMessage = e.Message;

            }
            catch (Exception)
            {

            }
        }

        private byte[] CalculateCheckSum(byte[] bytes)
        {
            short sum = 0;
            foreach (byte b in bytes)
            {
                sum += b;
            }

            byte[] checksum = BitConverter.GetBytes(sum);



            return checksum;
        }



        private bool ValidateCheckSum(byte[] bytes)
        {

            short sum = 0;
            foreach (byte b in bytes)
            {
                sum += b;
            }

            return sum == 0;
        }

        private static void Log(byte[] packet)
        {
            if (_logWriter == null || packet.Length <= 0)
                return;
            _logWriter.Write(packet);
        }

        #region IDisposable Members

        private bool _disposed;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing && !_stopData)
                {
                    _stopData = true;
                }
                //if (_stopPlcData)

                {
                    if (_serialHandler != null)
                        _serialHandler.Dispose();

                    //if (_mPlc != null)
                    //    _mPlc.Dispose();

                    _disposed = true;
                }

            }
        }


        #endregion

    }

    public struct Scalefactors
    {

        public const double Adc1 = 1;
        public const double Adc2 = 1;
        public const double Adc3 = 1;

        public const int ArraySize = 50;
    }
}
