﻿using AdcHmiFinal.BLL.Data;
using AdcHmiFinal.BLL.Handler;
using LiveCharts;
using System.ComponentModel;
using System.Windows;
using System.Windows.Threading;

namespace AdcHmiFinal
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IDisposable
    {
        private const int CountLimit = 50;
        private readonly ControlAgent? _Agent;
        private readonly DataViewModel? _ViewModel;
        private readonly BackgroundWorker _worker;
        private bool disposedValue;

        public event EventHandler? UiEvent;

        ChartValues<double> AdcOneValues { get; set; } = [];
        ChartValues<double> AdcTwoValues { get; set; } = [];
        ChartValues<double> AdcThreeValues { get; set; } = [];

        protected virtual void OnUiEvent(EventArgs e)
        {
            UiEvent?.Invoke(this, e);
        }

        public MainWindow()
        {
            InitializeComponent();
            _worker = new();
            _worker.DoWork += Worker_DoWork;
            _worker.WorkerReportsProgress = true;
            _worker.WorkerSupportsCancellation = true;

            AdcOneChart.Series[0].Values = AdcOneValues;
            AdcTwoChart.Series[0].Values = AdcTwoValues;
            AdcThreeChart.Series[0].Values = AdcThreeValues;


            BtnOn.IsEnabled = true;
            BtnOff.IsEnabled = false;

            _Agent = new();

            if (_Agent == null)
                return;

            _Agent.UISelected = true;
            var model = _Agent.DataViewModel;

            if (model != null)
                _ViewModel = model;

            UiEvent += _Agent.HandleCommands;

            StartBackgroundWorker();



        }

        private void StartBackgroundWorker()
        {
            if (_worker.IsBusy != true)
            {
                // Start the asynchronous operation.
                _worker.RunWorkerAsync();

            }
        }

        private void CancelBackgroundWorker()
        {
            if (_worker.WorkerSupportsCancellation == true)
            {
                // Cancel the asynchronous operation.
                _worker.CancelAsync();
            }
        }


        private void Worker_DoWork(object? sender, DoWorkEventArgs e)
        {
            var worker = sender as BackgroundWorker;
            if (worker != null && _ViewModel != null)
            {

                if (worker.CancellationPending == true)
                {
                    e.Cancel = true;

                }
                else
                {
                    do
                    {
                        Dispatcher.BeginInvoke(
                         new Action(() =>
                         {

                             
                             PlotValues(AdcOneValues, _ViewModel.AdcOneCounter, _ViewModel.AdcOne);
                             PlotValues(AdcTwoValues, _ViewModel.AdcTwoCounter, _ViewModel.AdcTwo);
                             PlotValues(AdcThreeValues, _ViewModel.AdcThreeCounter, _ViewModel.AdcThree);
                         }));

                        Thread.Sleep(100);
                    } while (true);

                }

            }
        }

        private void PlotValues(ChartValues<double> values, int counter, IList<double> yValues)
        {
            for (int i = 0; i < counter; i++)
            {
                try
                {
                    values.Add(yValues[i]);
                }
                catch (Exception)
                {


                }


            }


            if (values.Count > CountLimit)
            {
                values.RemoveAt(0);
            }
        }



        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {

            if (MessageBox.Show("Do you want to Exit?", "Visualizer", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {

                Dispose();
                Close();
            }
        }




        private void BtnOn_Click(object sender, RoutedEventArgs e)
        {

            BtnOn.IsEnabled = false;
            BtnOff.IsEnabled = true;

            if (_ViewModel != null)
            {
                _ViewModel.IsOnCommand = true;
                OnUiEvent(e);
            }
        }

        private void BtnOff_Click(object sender, RoutedEventArgs e)
        {
            BtnOn.IsEnabled = true;
            BtnOff.IsEnabled = false;

            if (_ViewModel != null)
            {
                _ViewModel.IsOnCommand = false;
                OnUiEvent(e);
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _Agent?.Dispose();
                    CancelBackgroundWorker();
                }

                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }

}